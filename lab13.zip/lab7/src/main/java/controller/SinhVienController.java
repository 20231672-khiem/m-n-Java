package controller;

import model.SinhVien;
import repository.SinhVienRepository;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/sinhvien")
public class SinhVienController extends HttpServlet {
    private SinhVienRepository repo = new SinhVienRepository();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if (action == null) action = "list";

        if (action.equals("list")) {
            req.setAttribute("danhSachSV", repo.getAll());
            req.getRequestDispatcher("/views/sinhvien-list.jsp").forward(req, resp);
        } else if (action.equals("add")) {
            req.getRequestDispatcher("/views/sinhvien-form.jsp").forward(req, resp);
        } else if (action.equals("delete")) {
            String maSV = req.getParameter("id");
            repo.delete(maSV);
            resp.sendRedirect("sinhvien"); // Xóa xong quay lại trang danh sách
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String maSV = req.getParameter("maSV");
        String hoTen = req.getParameter("hoTen");
        String nganhHoc = req.getParameter("nganhHoc");

        SinhVien sv = new SinhVien(maSV, hoTen, nganhHoc);
        repo.add(sv);

        resp.sendRedirect("sinhvien"); // Thêm xong quay lại trang danh sách
    }
}