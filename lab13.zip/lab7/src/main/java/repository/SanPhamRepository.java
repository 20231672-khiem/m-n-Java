package repository;

import model.SanPham;
import java.util.ArrayList;
import java.util.List;

public class SanPhamRepository {
    private static List<SanPham> danhSach = new ArrayList<>();

    // Dữ liệu mẫu
    static {
        danhSach.add(new SanPham("SP01", "Laptop Dell XPS", "Core i7, 16GB RAM", 25000000, 10));
        danhSach.add(new SanPham("SP02", "Chuột Logitech", "Chuột không dây", 350000, 50));
    }

    public List<SanPham> getAll() { return danhSach; }

    public void add(SanPham sp) { danhSach.add(sp); }

    public void delete(String maSP) {
        danhSach.removeIf(s -> s.getMaSP().equals(maSP));
    }
    // Hàm mới thêm cho Bài 10: Tìm sản phẩm theo mã
    public SanPham findById(String maSP) {
        return danhSach.stream()
                .filter(s -> s.getMaSP().equals(maSP))
                .findFirst()
                .orElse(null);
    }
}