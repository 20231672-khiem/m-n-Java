package model;

public class ItemGioHang {
    private SanPham sanPham;
    private int soLuongMua;

    public ItemGioHang() {}

    public ItemGioHang(SanPham sanPham, int soLuongMua) {
        this.sanPham = sanPham;
        this.soLuongMua = soLuongMua;
    }

    // Tự động tính thành tiền
    public double getThanhTien() {
        return sanPham.getGia() * soLuongMua;
    }

    public SanPham getSanPham() { return sanPham; }
    public void setSanPham(SanPham sanPham) { this.sanPham = sanPham; }
    public int getSoLuongMua() { return soLuongMua; }
    public void setSoLuongMua(int soLuongMua) { this.soLuongMua = soLuongMua; }
}