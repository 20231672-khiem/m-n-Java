package controller;

import model.SanPham;
import repository.SanPhamRepository;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/sanpham")
public class SanPhamController extends HttpServlet {
    private SanPhamRepository repo = new SanPhamRepository();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if (action == null) action = "list";

        if (action.equals("list")) {
            req.setAttribute("danhSachSP", repo.getAll());
            req.getRequestDispatcher("/views/sanpham-list.jsp").forward(req, resp);
        } else if (action.equals("add")) {
            req.getRequestDispatcher("/views/sanpham-form.jsp").forward(req, resp);
        } else if (action.equals("delete")) {
            String maSP = req.getParameter("id");
            repo.delete(maSP);
            resp.sendRedirect("sanpham");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");

        String maSP = req.getParameter("maSP");
        String tenSP = req.getParameter("tenSP");
        String moTa = req.getParameter("moTa");
        double gia = Double.parseDouble(req.getParameter("gia"));
        int soLuong = Integer.parseInt(req.getParameter("soLuong"));

        // Validate Server-side: Kiểm tra giá và số lượng
        if (gia <= 0 || soLuong < 0) {
            req.setAttribute("errorMessage", "Lỗi: Giá phải lớn hơn 0 và Số lượng phải từ 0 trở lên!");
            req.getRequestDispatcher("/views/sanpham-form.jsp").forward(req, resp);
            return; // Dừng lại, không thêm vào danh sách
        }

        SanPham sp = new SanPham(maSP, tenSP, moTa, gia, soLuong);
        repo.add(sp);

        resp.sendRedirect("sanpham");
    }
}