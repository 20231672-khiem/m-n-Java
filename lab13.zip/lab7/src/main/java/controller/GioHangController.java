package controller;

import model.ItemGioHang;
import model.SanPham;
import repository.SanPhamRepository;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/giohang")
public class GioHangController extends HttpServlet {
    private SanPhamRepository spRepo = new SanPhamRepository();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if (action == null) action = "view";

        // Lấy giỏ hàng từ Session
        HttpSession session = req.getSession();
        List<ItemGioHang> cart = (List<ItemGioHang>) session.getAttribute("cart");
        if (cart == null) {
            cart = new ArrayList<>(); // Nếu chưa có giỏ thì tạo mới
        }

        if (action.equals("add")) {
            String maSP = req.getParameter("id");
            SanPham sp = spRepo.findById(maSP);

            if (sp != null) {
                // Kiểm tra xem sản phẩm đã có trong giỏ chưa
                boolean exists = false;
                for (ItemGioHang item : cart) {
                    if (item.getSanPham().getMaSP().equals(maSP)) {
                        item.setSoLuongMua(item.getSoLuongMua() + 1); // Tăng số lượng
                        exists = true;
                        break;
                    }
                }
                if (!exists) {
                    cart.add(new ItemGioHang(sp, 1)); // Thêm mới vào giỏ
                }
            }
            session.setAttribute("cart", cart);
            resp.sendRedirect("giohang"); // Load lại trang giỏ hàng
            return;
        } else if (action.equals("delete")) {
            String maSP = req.getParameter("id");
            cart.removeIf(item -> item.getSanPham().getMaSP().equals(maSP));
            session.setAttribute("cart", cart);
            resp.sendRedirect("giohang");
            return;
        }

        // Action "view" - Tính tổng tiền và hiển thị
        double tongTien = 0;
        for (ItemGioHang item : cart) {
            tongTien += item.getThanhTien();
        }
        req.setAttribute("tongTien", tongTien);
        req.getRequestDispatcher("/views/giohang.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Xử lý Cập nhật số lượng
        String action = req.getParameter("action");
        if ("update".equals(action)) {
            String maSP = req.getParameter("id");
            int slMoi = Integer.parseInt(req.getParameter("soLuongMua"));

            HttpSession session = req.getSession();
            List<ItemGioHang> cart = (List<ItemGioHang>) session.getAttribute("cart");

            if (cart != null && slMoi > 0) {
                for (ItemGioHang item : cart) {
                    if (item.getSanPham().getMaSP().equals(maSP)) {
                        item.setSoLuongMua(slMoi);
                        break;
                    }
                }
            }
        }
        resp.sendRedirect("giohang");
    }
}