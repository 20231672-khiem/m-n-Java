<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Nhập Điểm Sinh Viên</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5" style="max-width: 500px;">
    <div class="card shadow">
        <div class="card-header bg-warning text-dark text-center">
            <h3 class="mb-0">Nhập Điểm Sinh Viên</h3>
        </div>
        <div class="card-body">
            <form action="diem" method="POST">
                <div class="mb-3">
                    <label class="form-label fw-bold">Mã Sinh Viên:</label>
                    <input type="text" name="maSV" class="form-control" required>
                </div>

                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label fw-bold">Điểm CC:</label>
                        <!-- Validate HTML5: Điểm từ 0 đến 10, cho phép số thập phân -->
                        <input type="number" name="diemCC" class="form-control" min="0" max="10" step="0.1" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label fw-bold">Điểm GK:</label>
                        <input type="number" name="diemGK" class="form-control" min="0" max="10" step="0.1" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label fw-bold">Điểm CK:</label>
                        <input type="number" name="diemCK" class="form-control" min="0" max="10" step="0.1" required>
                    </div>
                </div>

                <div class="d-grid gap-2 mt-3">
                    <button type="submit" class="btn btn-warning">Lưu Điểm</button>
                    <a href="diem" class="btn btn-outline-secondary">Hủy bỏ</a>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>