package repository;

import model.Sach;
import utils.FileUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class SachRepository {

    // Lấy toàn bộ danh sách từ file CSV thông qua FileUtils
    public List<Sach> getAll() {
        return FileUtils.loadFromFile();
    }

    // Thêm sách mới và tự động lưu xuống file
    public void add(Sach s) {
        List<Sach> danhSach = getAll();
        danhSach.add(s);
        FileUtils.saveToFile(danhSach);
    }

    // Xóa sách và tự động cập nhật lại file
    public void delete(String maSach) {
        List<Sach> danhSach = getAll();
        danhSach.removeIf(s -> s.getMaSach().equals(maSach));
        FileUtils.saveToFile(danhSach);
    }

    // Tìm kiếm theo tên hoặc tác giả (không phân biệt hoa thường)
    public List<Sach> search(String keyword) {
        List<Sach> danhSach = getAll();
        if (keyword == null || keyword.trim().isEmpty()) {
            return danhSach;
        }
        String kw = keyword.toLowerCase();
        return danhSach.stream()
                .filter(s -> s.getTenSach().toLowerCase().contains(kw) ||
                        s.getTacGia().toLowerCase().contains(kw))
                .collect(Collectors.toList());
    }

    // 1. Lấy danh sách giới hạn theo trang (phục vụ phân trang)
    public List<Sach> getPaginated(int offset, int limit) {
        List<Sach> all = getAll();
        int end = Math.min(offset + limit, all.size());
        if (offset > all.size()) {
            return new ArrayList<>();
        }
        return all.subList(offset, end);
    }

    // 2. Lấy tổng số lượng sách để tính tổng số trang
    public int getTotalCount() {
        return getAll().size();
    }
}