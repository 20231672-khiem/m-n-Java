package controller;

import model.LopHoc;
import repository.LopHocRepository;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/lophoc")
public class LopHocController extends HttpServlet {
    private LopHocRepository repo = new LopHocRepository();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if (action == null) action = "list";

        if (action.equals("list")) {
            String keyword = req.getParameter("keyword");
            if (keyword != null && !keyword.isEmpty()) {
                req.setAttribute("danhSachLop", repo.search(keyword));
                req.setAttribute("keyword", keyword);
            } else {
                req.setAttribute("danhSachLop", repo.getAll());
            }
            req.getRequestDispatcher("/views/lophoc-list.jsp").forward(req, resp);
        } else if (action.equals("add")) {
            req.getRequestDispatcher("/views/lophoc-form.jsp").forward(req, resp);
        } else if (action.equals("delete")) {
            String maLop = req.getParameter("id");
            repo.delete(maLop);
            resp.sendRedirect("lophoc");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");

        String maLop = req.getParameter("maLop");
        String tenLop = req.getParameter("tenLop");
        String coVan = req.getParameter("coVanHocTap");
        int soLuong = Integer.parseInt(req.getParameter("soLuongSV"));

        LopHoc lh = new LopHoc(maLop, tenLop, coVan, soLuong);
        repo.add(lh);

        resp.sendRedirect("lophoc");
    }
}