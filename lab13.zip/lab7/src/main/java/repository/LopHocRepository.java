package repository;

import model.LopHoc;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class LopHocRepository {
    private static List<LopHoc> danhSach = new ArrayList<>();

    // Dữ liệu mẫu
    static {
        danhSach.add(new LopHoc("IT01", "Công nghệ thông tin 1", "Nguyễn Văn A", 45));
        danhSach.add(new LopHoc("IT02", "Công nghệ thông tin 2", "Trần Thị B", 42));
        danhSach.add(new LopHoc("KT01", "Kế toán doanh nghiệp", "Lê Văn C", 50));
    }

    public List<LopHoc> getAll() { return danhSach; }

    public void add(LopHoc lh) { danhSach.add(lh); }

    public void delete(String maLop) {
        danhSach.removeIf(l -> l.getMaLop().equals(maLop));
    }

    // Tìm kiếm theo Mã lớp HOẶC Tên lớp
    public List<LopHoc> search(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return danhSach;
        }
        String kw = keyword.toLowerCase();
        return danhSach.stream()
                .filter(l -> l.getMaLop().toLowerCase().contains(kw) ||
                        l.getTenLop().toLowerCase().contains(kw))
                .collect(Collectors.toList());
    }
}