<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<html>
<head>
    <title>Quản lý Lớp học</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2 class="mb-3">Quản lý Lớp học</h2>

    <div class="d-flex justify-content-between mb-3">
        <div>
            <a href="lophoc?action=add" class="btn btn-success">Thêm Lớp học mới</a>
            <a href="index.jsp" class="btn btn-secondary">Về trang chủ</a>
        </div>

        <!-- Form tìm kiếm -->
        <form action="lophoc" method="GET" class="d-flex">
            <input type="hidden" name="action" value="list">
            <input type="text" name="keyword" value="${keyword}" class="form-control me-2" placeholder="Nhập mã hoặc tên lớp...">
            <button type="submit" class="btn btn-primary">Tìm kiếm</button>
        </form>
    </div>

    <table class="table table-bordered table-striped table-hover">
        <thead class="table-dark">
        <tr>
            <th>Mã Lớp</th>
            <th>Tên Lớp</th>
            <th>Cố Vấn Học Tập</th>
            <th>Sĩ số (SV)</th>
            <th>Hành động</th>
        </tr>
        </thead>
        <tbody>
        <c:forEach items="${danhSachLop}" var="lh">
            <tr>
                <td>${lh.maLop}</td>
                <td>${lh.tenLop}</td>
                <td>${lh.coVanHocTap}</td>
                <td>${lh.soLuongSV}</td>
                <td>
                    <a href="lophoc?action=delete&id=${lh.maLop}"
                       class="btn btn-danger btn-sm"
                       onclick="return confirm('Bạn có chắc chắn muốn xóa lớp học này?');">Xóa</a>
                </td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
</div>
</body>
</html>