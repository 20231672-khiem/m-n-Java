<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<html>
<head>
    <title>Quản lý Điểm Sinh Viên</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2 class="mb-3">Quản lý Điểm Sinh Viên</h2>

    <div class="mb-3">
        <a href="diem?action=add" class="btn btn-success">Nhập điểm mới</a>
        <a href="index.jsp" class="btn btn-secondary">Về trang chủ</a>
    </div>

    <table class="table table-bordered table-striped table-hover text-center">
        <thead class="table-dark">
        <tr>
            <th>Mã SV</th>
            <th>Điểm CC (10%)</th>
            <th>Điểm GK (30%)</th>
            <th>Điểm CK (60%)</th>
            <th>Tổng Kết</th>
            <th>Xếp Loại</th>
            <th>Hành động</th>
        </tr>
        </thead>
        <tbody>
        <c:forEach items="${danhSachDiem}" var="d">
            <tr>
                <td>${d.maSV}</td>
                <td>${d.diemCC}</td>
                <td>${d.diemGK}</td>
                <td>${d.diemCK}</td>
                <!-- Định dạng điểm tổng kết lấy 1 chữ số thập phân -->
                <td class="fw-bold text-primary">
                    <fmt:formatNumber value="${d.tongKet}" type="number" maxFractionDigits="1"/>
                </td>
                <!-- Xếp loại A, B, C, D, F tự động lấy từ Model -->
                <td class="fw-bold text-danger">${d.xepLoai}</td>
                <td>
                    <a href="diem?action=delete&id=${d.maSV}"
                       class="btn btn-danger btn-sm"
                       onclick="return confirm('Bạn có chắc chắn muốn xóa?');">Xóa</a>
                </td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
</div>
</body>
</html>