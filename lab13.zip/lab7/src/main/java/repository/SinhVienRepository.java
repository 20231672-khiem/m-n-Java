package repository;

import model.SinhVien;
import java.util.ArrayList;
import java.util.List;

public class SinhVienRepository {
    private static List<SinhVien> danhSach = new ArrayList<>();

    // Dữ liệu mẫu ban đầu
    static {
        danhSach.add(new SinhVien("SV01", "Trần Nguyên Hoàng", "Công nghệ Thông tin"));
        danhSach.add(new SinhVien("SV02", "Nguyễn Văn A", "Kinh tế"));
    }

    public List<SinhVien> getAll() { return danhSach; }

    public void add(SinhVien sv) { danhSach.add(sv); }

    public void delete(String maSV) {
        danhSach.removeIf(s -> s.getMaSV().equals(maSV));
    }
}