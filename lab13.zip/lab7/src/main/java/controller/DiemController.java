package controller;

import model.Diem;
import repository.DiemRepository;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/diem")
public class DiemController extends HttpServlet {
    private DiemRepository repo = new DiemRepository();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if (action == null) action = "list";

        if (action.equals("list")) {
            req.setAttribute("danhSachDiem", repo.getAll());
            req.getRequestDispatcher("/views/diem-list.jsp").forward(req, resp);
        } else if (action.equals("add")) {
            req.getRequestDispatcher("/views/diem-form.jsp").forward(req, resp);
        } else if (action.equals("delete")) {
            String maSV = req.getParameter("id");
            repo.delete(maSV);
            resp.sendRedirect("diem");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String maSV = req.getParameter("maSV");
        double diemCC = Double.parseDouble(req.getParameter("diemCC"));
        double diemGK = Double.parseDouble(req.getParameter("diemGK"));
        double diemCK = Double.parseDouble(req.getParameter("diemCK"));

        Diem d = new Diem(maSV, diemCC, diemGK, diemCK);
        repo.add(d);

        resp.sendRedirect("diem");
    }
}