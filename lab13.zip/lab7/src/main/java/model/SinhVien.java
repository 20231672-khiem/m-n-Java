package model;

public class SinhVien {
    private String maSV;
    private String hoTen;
    private String nganhHoc;

    public SinhVien() {}

    public SinhVien(String maSV, String hoTen, String nganhHoc) {
        this.maSV = maSV;
        this.hoTen = hoTen;
        this.nganhHoc = nganhHoc;
    }

    // Getters và Setters
    public String getMaSV() { return maSV; }
    public void setMaSV(String maSV) { this.maSV = maSV; }
    public String getHoTen() { return hoTen; }
    public void setHoTen(String hoTen) { this.hoTen = hoTen; }
    public String getNganhHoc() { return nganhHoc; }
    public void setNganhHoc(String nganhHoc) { this.nganhHoc = nganhHoc; }
}