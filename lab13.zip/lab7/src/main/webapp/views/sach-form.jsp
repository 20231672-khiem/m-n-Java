<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Thêm Sách</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5" style="max-width: 500px;">
    <div class="card shadow">
        <div class="card-header bg-success text-white text-center">
            <h3 class="mb-0">Thêm Sách Mới</h3>
        </div>
        <div class="card-body">
            <form action="sach" method="POST">
                <div class="mb-3">
                    <label class="form-label fw-bold">Mã Sách:</label>
                    <input type="text" name="maSach" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Tên Sách:</label>
                    <input type="text" name="tenSach" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Tác Giả:</label>
                    <input type="text" name="tacGia" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Nhà Xuất Bản:</label>
                    <input type="text" name="nhaXuatBan" class="form-control" required>
                </div>
                <div class="mb-4">
                    <label class="form-label fw-bold">Năm Xuất Bản:</label>
                    <input type="number" name="namXuatBan" class="form-control" min="1000" max="2100" required>
                </div>
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-success">Lưu thông tin</button>
                    <a href="sach" class="btn btn-outline-secondary">Hủy bỏ</a>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>