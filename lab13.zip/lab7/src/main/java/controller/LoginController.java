package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/login")
public class LoginController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if ("logout".equals(action)) {
            HttpSession session = req.getSession();
            session.invalidate(); // Xóa session khi đăng xuất
            resp.sendRedirect("login");
            return;
        }
        req.getRequestDispatcher("/login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String user = req.getParameter("username");
        String pass = req.getParameter("password");

        // Hardcode tài khoản admin để test nhanh chức năng
        if ("admin".equals(user) && "123456".equals(pass)) {
            HttpSession session = req.getSession();
            session.setAttribute("userLog", user); // Lưu thông tin đăng nhập vào Session
            resp.sendRedirect("index.jsp"); // Đăng nhập thành công, đẩy về trang chủ
        } else {
            // Đăng nhập thất bại, báo lỗi và giữ lại ở trang đăng nhập
            req.setAttribute("errorMessage", "Sai tài khoản hoặc mật khẩu!");
            req.getRequestDispatcher("/login.jsp").forward(req, resp);
        }
    }
}