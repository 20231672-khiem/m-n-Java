<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Thêm Lớp Học</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5" style="max-width: 500px;">
    <div class="card shadow">
        <div class="card-header bg-info text-white text-center">
            <h3 class="mb-0">Thêm Lớp Học Mới</h3>
        </div>
        <div class="card-body">
            <form action="lophoc" method="POST">
                <div class="mb-3">
                    <label class="form-label fw-bold">Mã Lớp:</label>
                    <input type="text" name="maLop" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Tên Lớp:</label>
                    <input type="text" name="tenLop" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Cố Vấn Học Tập:</label>
                    <input type="text" name="coVanHocTap" class="form-control" required>
                </div>
                <div class="mb-4">
                    <label class="form-label fw-bold">Số lượng sinh viên:</label>
                    <input type="number" name="soLuongSV" class="form-control" min="0" required>
                </div>
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-info text-white">Lưu thông tin</button>
                    <a href="lophoc" class="btn btn-outline-secondary">Hủy bỏ / Quay lại</a>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>