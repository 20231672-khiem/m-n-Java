package utils;

import model.Sach;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FileUtils {
    // Đường dẫn file lưu trữ nằm trực tiếp tại thư mục gốc của project
    private static final String FILE_PATH = "sachs_data.csv";

    // 1. Ghi danh sách sách ra file CSV
    public static void saveToFile(List<Sach> danhSach) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(FILE_PATH))) {
            for (Sach s : danhSach) {
                pw.println(s.getMaSach() + "," + s.getTenSach() + "," + s.getTacGia() + "," + s.getNhaXuatBan() + "," + s.getNamXuatBan());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 2. Đọc danh sách sách từ file CSV khi khởi động
    public static List<Sach> loadFromFile() {
        List<Sach> danhSach = new ArrayList<>();
        File file = new File(FILE_PATH);
        if (!file.exists()) {
            return danhSach; // Trả về danh sách rỗng nếu file chưa tồn tại
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 5) {
                    Sach s = new Sach(parts[0], parts[1], parts[2], parts[3], Integer.parseInt(parts[4]));
                    danhSach.add(s);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return danhSach;
    }
}