package repository;

import model.Diem;
import java.util.ArrayList;
import java.util.List;

public class DiemRepository {
    private static List<Diem> danhSach = new ArrayList<>();

    static {
        danhSach.add(new Diem("SV01", 10.0, 8.5, 9.0)); // Sẽ tự tính ra A
        danhSach.add(new Diem("SV02", 9.0, 6.0, 5.0));  // Sẽ tự tính ra C
    }

    public List<Diem> getAll() { return danhSach; }

    public void add(Diem d) { danhSach.add(d); }

    public void delete(String maSV) {
        danhSach.removeIf(d -> d.getMaSV().equals(maSV));
    }
}