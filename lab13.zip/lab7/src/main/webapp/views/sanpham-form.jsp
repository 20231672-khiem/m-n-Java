<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
  <title>Thêm Sản Phẩm</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5" style="max-width: 500px;">
  <div class="card shadow">
    <div class="card-header bg-primary text-white text-center">
      <h3 class="mb-0">Thêm Sản Phẩm Mới</h3>
    </div>
    <div class="card-body">
      <!-- Hiện thông báo lỗi Validate từ Server (nếu có) -->
      <% String error = (String) request.getAttribute("errorMessage");
        if (error != null) { %>
      <div class="alert alert-danger"><%= error %></div>
      <% } %>

      <form action="sanpham" method="POST">
        <div class="mb-3">
          <label class="form-label fw-bold">Mã Sản phẩm:</label>
          <input type="text" name="maSP" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label fw-bold">Tên Sản phẩm:</label>
          <input type="text" name="tenSP" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label fw-bold">Mô tả:</label>
          <textarea name="moTa" class="form-control" rows="2" required></textarea>
        </div>
        <div class="row">
          <div class="col-md-6 mb-3">
            <label class="form-label fw-bold">Giá (VNĐ):</label>
            <!-- Validate HTML5: min="0.01" để bắt buộc nhập số > 0 -->
            <input type="number" name="gia" class="form-control" min="0.01" step="any" required>
          </div>
          <div class="col-md-6 mb-3">
            <label class="form-label fw-bold">Số lượng:</label>
            <!-- Validate HTML5: min="0" để bắt buộc nhập số >= 0 -->
            <input type="number" name="soLuong" class="form-control" min="0" required>
          </div>
        </div>
        <div class="d-grid gap-2 mt-3">
          <button type="submit" class="btn btn-primary">Lưu Sản phẩm</button>
          <a href="sanpham" class="btn btn-outline-secondary">Hủy bỏ</a>
        </div>
      </form>
    </div>
  </div>
</div>
</body>
</html>