<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!-- Khai báo thư viện JSTL để dùng vòng lặp -->
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<html>
<head>
    <title>Danh sách Sinh Viên</title>
    <!-- Nhúng thư viện CSS Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2 class="mb-3">Quản lý Sinh viên</h2>

    <!-- Các nút điều hướng -->
    <div class="mb-3">
        <!-- Gọi Controller với action=add để mở form thêm mới -->
        <a href="sinhvien?action=add" class="btn btn-success">Thêm mới sinh viên</a>
        <a href="index.jsp" class="btn btn-secondary">Về trang chủ</a>
    </div>

    <!-- Bảng hiển thị dữ liệu -->
    <table class="table table-bordered table-striped table-hover">
        <thead class="table-dark">
        <tr>
            <th>Mã SV</th>
            <th>Họ Tên</th>
            <th>Ngành Học</th>
            <th>Hành động</th>
        </tr>
        </thead>
        <tbody>
        <!-- Vòng lặp foreach duyệt qua danhSachSV được gửi từ Controller -->
        <c:forEach items="${danhSachSV}" var="sv">
            <tr>
                <td>${sv.maSV}</td>
                <td>${sv.hoTen}</td>
                <td>${sv.nganhHoc}</td>
                <td>
                    <!-- Nút Xóa có kèm xác nhận bằng JavaScript -->
                    <a href="sinhvien?action=delete&id=${sv.maSV}"
                       class="btn btn-danger btn-sm"
                       onclick="return confirm('Bạn có chắc chắn muốn xóa sinh viên ${sv.hoTen} này không?');">Xóa</a>
                </td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
</div>
</body>
</html>