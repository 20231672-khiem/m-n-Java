<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Thêm Sinh Viên</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5" style="max-width: 500px;">
    <div class="card shadow">
        <div class="card-header bg-primary text-white text-center">
            <h3 class="mb-0">Thêm Sinh Viên Mới</h3>
        </div>
        <div class="card-body">
            <!-- Form gửi dữ liệu (POST) về Controller có URL là /sinhvien -->
            <form action="sinhvien" method="POST">
                <div class="mb-3">
                    <label class="form-label fw-bold">Mã Sinh Viên:</label>
                    <!-- name="maSV" phải khớp chính xác với req.getParameter("maSV") trong Controller -->
                    <input type="text" name="maSV" class="form-control" placeholder="Nhập mã SV..." required>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold">Họ và Tên:</label>
                    <input type="text" name="hoTen" class="form-control" placeholder="Nhập họ tên..." required>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-bold">Ngành học:</label>
                    <input type="text" name="nganhHoc" class="form-control" placeholder="Ví dụ: Công nghệ thông tin" required>
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary">Lưu thông tin</button>
                    <!-- Nút Hủy sẽ gọi lại Controller ở chế độ mặc định (hiển thị danh sách) -->
                    <a href="sinhvien" class="btn btn-outline-secondary">Hủy bỏ / Quay lại</a>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>