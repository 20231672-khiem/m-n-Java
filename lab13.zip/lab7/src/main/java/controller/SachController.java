package controller;

import model.Sach;
import repository.SachRepository;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;

@WebServlet("/sach")
public class SachController extends HttpServlet {
    private SachRepository repo = new SachRepository();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if (action == null) action = "list";

        if (action.equals("list")) {
            String keyword = req.getParameter("keyword");

            // Xử lý phân trang
            int pageSize = 2; // Số lượng sách hiển thị trên 1 trang
            int page = 1;     // Mặc định là trang 1
            String pageStr = req.getParameter("page");
            if (pageStr != null && !pageStr.isEmpty()) {
                try {
                    page = Integer.parseInt(pageStr);
                } catch (NumberFormatException e) {
                    page = 1;
                }
            }

            List<Sach> listToShow;
            int totalRecords;

            if (keyword != null && !keyword.isEmpty()) {
                List<Sach> searchResult = repo.search(keyword);
                totalRecords = searchResult.size();

                int start = (page - 1) * pageSize;
                int end = Math.min(start + pageSize, totalRecords);
                listToShow = (start <= totalRecords) ? searchResult.subList(start, end) : new ArrayList<>();

                req.setAttribute("keyword", keyword);
            } else {
                totalRecords = repo.getTotalCount();
                int offset = (page - 1) * pageSize;
                listToShow = repo.getPaginated(offset, pageSize);
            }

            int totalPages = (int) Math.ceil((double) totalRecords / pageSize);

            req.setAttribute("danhSachSach", listToShow);
            req.setAttribute("currentPage", page);
            req.setAttribute("totalPages", totalPages);

            req.getRequestDispatcher("/views/sach-list.jsp").forward(req, resp);
        } else if (action.equals("add")) {
            req.getRequestDispatcher("/views/sach-form.jsp").forward(req, resp);
        } else if (action.equals("delete")) {
            String maSach = req.getParameter("id");
            repo.delete(maSach);
            resp.sendRedirect("sach");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String maSach = req.getParameter("maSach");
        String tenSach = req.getParameter("tenSach");
        String tacGia = req.getParameter("tacGia");
        String nhaXuatBan = req.getParameter("nhaXuatBan");
        int namXuatBan = Integer.parseInt(req.getParameter("namXuatBan"));

        Sach s = new Sach(maSach, tenSach, tacGia, nhaXuatBan, namXuatBan);
        repo.add(s);

        resp.sendRedirect("sach");
    }
}