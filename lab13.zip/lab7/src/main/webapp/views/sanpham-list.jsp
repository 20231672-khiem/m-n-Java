<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %> <!-- Thư viện Format số tiền -->
<html>
<head>
    <title>Quản lý Sản phẩm</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2 class="mb-3">Quản lý Sản phẩm</h2>
    <div class="mb-3">
        <a href="sanpham?action=add" class="btn btn-success">Thêm Sản phẩm</a>
        <a href="index.jsp" class="btn btn-secondary">Về trang chủ</a>
    </div>

    <table class="table table-bordered table-striped table-hover">
        <thead class="table-dark">
        <tr>
            <th>Mã SP</th>
            <th>Tên SP</th>
            <th>Mô tả</th>
            <th>Giá (VNĐ)</th>
            <th>Số lượng</th>
            <th>Hành động</th>
        </tr>
        </thead>
        <tbody>
        <c:forEach items="${danhSachSP}" var="sp">
            <tr>
                <td>${sp.maSP}</td>
                <td>${sp.tenSP}</td>
                <td>${sp.moTa}</td>
                <!-- Format số tiền cho đẹp -->
                <td><fmt:formatNumber value="${sp.gia}" type="number" maxFractionDigits="0"/></td>
                <td>${sp.soLuong}</td>
                <td>
                    <!-- Đã thêm nút Mua ngay gọi đến GioHangController -->
                    <a href="giohang?action=add&id=${sp.maSP}" class="btn btn-warning btn-sm">Mua ngay</a>

                    <a href="sanpham?action=delete&id=${sp.maSP}"
                       class="btn btn-danger btn-sm" onclick="return confirm('Xóa sản phẩm này?');">Xóa</a>
                </td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
</div>
</body>
</html>