<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<html>
<head>
    <title>Giỏ hàng của bạn</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2 class="mb-3 text-primary">Giỏ hàng của bạn</h2>

    <div class="mb-3">
        <a href="sanpham" class="btn btn-outline-primary">Tiếp tục mua sắm</a>
        <a href="index.jsp" class="btn btn-secondary">Về trang chủ</a>
    </div>

    <c:if test="${empty sessionScope.cart}">
        <div class="alert alert-warning">Giỏ hàng của bạn đang trống!</div>
    </c:if>

    <c:if test="${not empty sessionScope.cart}">
        <table class="table table-bordered table-striped align-middle">
            <thead class="table-dark text-center">
            <tr>
                <th>Mã SP</th>
                <th>Tên Sản phẩm</th>
                <th>Đơn giá</th>
                <th>Số lượng</th>
                <th>Thành tiền</th>
                <th>Hành động</th>
            </tr>
            </thead>
            <tbody>
            <c:forEach items="${sessionScope.cart}" var="item">
                <tr>
                    <td class="text-center">${item.sanPham.maSP}</td>
                    <td>${item.sanPham.tenSP}</td>
                    <td class="text-end">
                        <fmt:formatNumber value="${item.sanPham.gia}" type="number" maxFractionDigits="0"/> đ
                    </td>
                    <td class="text-center" style="width: 150px;">
                        <!-- Form Cập nhật số lượng -->
                        <form action="giohang?action=update&id=${item.sanPham.maSP}" method="POST" class="d-flex mb-0">
                            <input type="number" name="soLuongMua" value="${item.soLuongMua}" min="1" class="form-control form-control-sm me-1">
                            <button type="submit" class="btn btn-success btn-sm">Cập nhật</button>
                        </form>
                    </td>
                    <td class="text-end fw-bold text-danger">
                        <fmt:formatNumber value="${item.thanhTien}" type="number" maxFractionDigits="0"/> đ
                    </td>
                    <td class="text-center">
                        <a href="giohang?action=delete&id=${item.sanPham.maSP}" class="btn btn-danger btn-sm" onclick="return confirm('Bỏ sản phẩm này?');">Xóa</a>
                    </td>
                </tr>
            </c:forEach>
            </tbody>
            <tfoot>
            <tr>
                <td colspan="4" class="text-end fw-bold fs-5">Tổng cộng:</td>
                <td colspan="2" class="fw-bold fs-5 text-danger">
                    <fmt:formatNumber value="${tongTien}" type="number" maxFractionDigits="0"/> VNĐ
                </td>
            </tr>
            </tfoot>
        </table>

        <div class="text-end">
            <button class="btn btn-primary btn-lg">Tiến hành Thanh toán</button>
        </div>
    </c:if>
</div>
</body>
</html>