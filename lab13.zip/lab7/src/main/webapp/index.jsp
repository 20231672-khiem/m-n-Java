<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<html>
<head>
    <title>Hệ thống Quản lý Lab 7 - Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-light">

<!-- Navbar chung -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold" href="index.jsp"><i class="fas fa-laptop-code"></i> Lab 7 MVC</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ms-auto">
                <c:choose>
                    <c:when test="${not empty sessionScope.userLog}">
                        <li class="nav-item">
                            <span class="nav-link text-warning"><i class="fas fa-user-shield"></i> Xin chào, ${sessionScope.userLog}</span>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-danger" href="login?action=logout"><i class="fas fa-sign-out-alt"></i> Đăng xuất</a>
                        </li>
                    </c:when>
                    <c:otherwise>
                        <li class="nav-item">
                            <a class="nav-link" href="login"><i class="fas fa-sign-in-alt"></i> Đăng nhập</a>
                        </li>
                    </c:otherwise>
                </c:choose>
            </ul>
        </div>
    </div>
</nav>

<!-- Main Dashboard Content -->
<div class="container py-5">
    <div class="text-center mb-5">
        <h1 class="fw-bold text-primary">Hệ Thống Quản Lý Đa Chức Năng</h1>
        <p class="text-muted">Đồ án Java Web MVC hoàn thiện - Lab 7 (Servlet, JSP, Maven, Session, File IO)</p>
    </div>

    <div class="row g-4">
        <!-- Quản lý Sinh viên -->
        <div class="col-md-4">
            <div class="card shadow-sm h-100 border-0">
                <div class="card-body text-center p-4">
                    <div class="text-primary fs-1 mb-3"><i class="fas fa-user-graduate"></i></div>
                    <h4 class="card-title fw-bold">Quản lý Sinh viên</h4>
                    <p class="card-text text-muted">Thêm, sửa, xóa và hiển thị danh sách sinh viên chuẩn mô hình MVC.</p>
                    <a href="sinhvien" class="btn btn-outline-primary stretched-link">Truy cập module</a>
                </div>
            </div>
        </div>

        <!-- Quản lý Sách -->
        <div class="col-md-4">
            <div class="card shadow-sm h-100 border-0">
                <div class="card-body text-center p-4">
                    <div class="text-success fs-1 mb-3"><i class="fas fa-book"></i></div>
                    <h4 class="card-title fw-bold">Quản lý Sách</h4>
                    <p class="card-text text-muted">Hỗ trợ tìm kiếm thông minh, phân trang và lưu trữ bền vững qua File CSV.</p>
                    <a href="sach" class="btn btn-outline-success stretched-link">Truy cập module</a>
                </div>
            </div>
        </div>

        <!-- Quản lý Sản phẩm -->
        <div class="col-md-4">
            <div class="card shadow-sm h-100 border-0">
                <div class="card-body text-center p-4">
                    <div class="text-warning fs-1 mb-3"><i class="fas fa-box-open"></i></div>
                    <h4 class="card-title fw-bold">Quản lý Sản phẩm</h4>
                    <p class="card-text text-muted">CRUD sản phẩm, kiểm tra dữ liệu đầu vào (Validate) giá và số lượng.</p>
                    <a href="sanpham" class="btn btn-outline-warning stretched-link">Truy cập module</a>
                </div>
            </div>
        </div>

        <!-- Quản lý Lớp học -->
        <div class="col-md-4">
            <div class="card shadow-sm h-100 border-0">
                <div class="card-body text-center p-4">
                    <div class="text-info fs-1 mb-3"><i class="fas fa-school"></i></div>
                    <h4 class="card-title fw-bold">Quản lý Lớp học</h4>
                    <p class="card-text text-muted">Quản lý danh sách lớp học, cố vấn học tập và tra cứu sĩ số sinh viên.</p>
                    <a href="lophoc" class="btn btn-outline-info stretched-link">Truy cập module</a>
                </div>
            </div>
        </div>

        <!-- Quản lý Điểm -->
        <div class="col-md-4">
            <div class="card shadow-sm h-100 border-0">
                <div class="card-body text-center p-4">
                    <div class="text-danger fs-1 mb-3"><i class="fas fa-chart-line"></i></div>
                    <h4 class="card-title fw-bold">Quản lý Điểm</h4>
                    <p class="card-text text-muted">Tự động tính điểm tổng kết hệ số và xếp loại học lực (A, B, C, D, F).</p>
                    <a href="diem" class="btn btn-outline-danger stretched-link">Truy cập module</a>
                </div>
            </div>
        </div>

        <!-- Giỏ hàng Session -->
        <div class="col-md-4">
            <div class="card shadow-sm h-100 border-0">
                <div class="card-body text-center p-4">
                    <div class="text-secondary fs-1 mb-3"><i class="fas fa-shopping-cart"></i></div>
                    <h4 class="card-title fw-bold">Giỏ hàng</h4>
                    <p class="card-text text-muted">Quản lý giỏ hàng thông qua HTTP Session, tính tiền và thanh toán trực tuyến.</p>
                    <a href="giohang" class="btn btn-outline-secondary stretched-link">Truy cập module</a>
                </div>
            </div>
        </div>
    </div>
</div>

<footer class="text-center py-4 text-muted border-top mt-5">
    <p class="mb-0">Java Web MVC Project - Hoàn thành Lab 7 thành công rực rỡ!</p>
</footer>

</body>
</html>