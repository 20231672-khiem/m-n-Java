package model;

public class Diem {
    private String maSV;
    private double diemCC; // Chuyên cần
    private double diemGK; // Giữa kỳ
    private double diemCK; // Cuối kỳ

    public Diem() {}

    public Diem(String maSV, double diemCC, double diemGK, double diemCK) {
        this.maSV = maSV;
        this.diemCC = diemCC;
        this.diemGK = diemGK;
        this.diemCK = diemCK;
    }

    // Logic tính điểm tổng kết (10% CC + 30% GK + 60% CK)
    public double getTongKet() {
        return (diemCC * 0.1) + (diemGK * 0.3) + (diemCK * 0.6);
    }

    // Logic tự động xếp loại
    public String getXepLoai() {
        double tk = getTongKet();
        if (tk >= 8.5) return "A";
        else if (tk >= 7.0) return "B";
        else if (tk >= 5.5) return "C";
        else if (tk >= 4.0) return "D";
        else return "F";
    }

    // Getters và Setters cho các trường cơ bản
    public String getMaSV() { return maSV; }
    public void setMaSV(String maSV) { this.maSV = maSV; }
    public double getDiemCC() { return diemCC; }
    public void setDiemCC(double diemCC) { this.diemCC = diemCC; }
    public double getDiemGK() { return diemGK; }
    public void setDiemGK(double diemGK) { this.diemGK = diemGK; }
    public double getDiemCK() { return diemCK; }
    public void setDiemCK(double diemCK) { this.diemCK = diemCK; }
}