package model;

public class LopHoc {
    private String maLop;
    private String tenLop;
    private String coVanHocTap;
    private int soLuongSV;

    public LopHoc() {}

    public LopHoc(String maLop, String tenLop, String coVanHocTap, int soLuongSV) {
        this.maLop = maLop;
        this.tenLop = tenLop;
        this.coVanHocTap = coVanHocTap;
        this.soLuongSV = soLuongSV;
    }

    // Getters và Setters
    public String getMaLop() { return maLop; }
    public void setMaLop(String maLop) { this.maLop = maLop; }
    public String getTenLop() { return tenLop; }
    public void setTenLop(String tenLop) { this.tenLop = tenLop; }
    public String getCoVanHocTap() { return coVanHocTap; }
    public void setCoVanHocTap(String coVanHocTap) { this.coVanHocTap = coVanHocTap; }
    public int getSoLuongSV() { return soLuongSV; }
    public void setSoLuongSV(int soLuongSV) { this.soLuongSV = soLuongSV; }
}