<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<html>
<head>
    <title>Quản lý Sách</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2 class="mb-3">Quản lý Sách</h2>

    <div class="d-flex justify-content-between mb-3">
        <div>
            <a href="sach?action=add" class="btn btn-success">Thêm Sách mới</a>
            <a href="index.jsp" class="btn btn-secondary">Về trang chủ</a>
        </div>

        <!-- Form tìm kiếm -->
        <form action="sach" method="GET" class="d-flex">
            <input type="hidden" name="action" value="list">
            <input type="text" name="keyword" value="${keyword}" class="form-control me-2" placeholder="Tìm tên sách, tác giả...">
            <button type="submit" class="btn btn-primary">Tìm</button>
        </form>
    </div>

    <table class="table table-bordered table-hover">
        <thead class="table-dark">
        <tr>
            <th>Mã Sách</th>
            <th>Tên Sách</th>
            <th>Tác Giả</th>
            <th>Nhà Xuất Bản</th>
            <th>Năm XB</th>
            <th>Hành động</th>
        </tr>
        </thead>
        <tbody>
        <c:forEach items="${danhSachSach}" var="s">
            <tr>
                <td>${s.maSach}</td>
                <td>${s.tenSach}</td>
                <td>${s.tacGia}</td>
                <td>${s.nhaXuatBan}</td>
                <td>${s.namXuatBan}</td>
                <td>
                    <a href="sach?action=delete&id=${s.maSach}"
                       class="btn btn-danger btn-sm"
                       onclick="return confirm('Xóa sách này?');">Xóa</a>
                </td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
    <!-- Thanh Phân trang Bootstrap -->
    <c:if test="${totalPages > 1}">
        <nav aria-label="Page navigation" class="mt-4">
            <ul class="pagination justify-content-center">
                <!-- Nút Previous -->
                <li class="page-item ${currentPage == 1 ? 'disabled' : ''}">
                    <a class="page-link" href="sach?action=list&page=${currentPage - 1}&keyword=${keyword != null ? keyword : ''}">Trước</a>
                </li>

                <!-- Vòng lặp các số trang -->
                <c:forEach begin="1" end="${totalPages}" var="i">
                    <li class="page-item ${currentPage == i ? 'active' : ''}">
                        <a class="page-link" href="sach?action=list&page=${i}&keyword=${keyword != null ? keyword : ''}">${i}</a>
                    </li>
                </c:forEach>

                <!-- Nút Next -->
                <li class="page-item ${currentPage ==totalPages ? 'disabled' : ''}">
                    <a class="page-link" href="sach?action=list&page=${currentPage + 1}&keyword=${keyword != null ? keyword : ''}">Sau</a>
                </li>
            </ul>
        </nav>
    </c:if>
</div>
</body>
</html>